<?php
function remove_double_slash($url)
{
    return str_replace("//","/",$url);
}