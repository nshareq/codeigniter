<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\UserDetailsModel;

class Home extends BaseController
{
    public function index()
    {
        return view('welcome_message');
    }

    public function register()
    {
        if ($this->request->getMethod() == "get") {
            echo view('register');
        } elseif ($this->request->getMethod() == "post") {
            if ($this->validate([
                "username" => "required",
                "email" => "required|valid_email",
                "password" => "required|min_length[5]|max_length[15]",
                "cpassword" => "matches[password]"
            ])) {
                $username = $this->request->getVar("username");
                $email = $this->request->getVar("email");
                $password = $this->request->getVar("password");

                $data = [
                    "username" => $username,
                    "email" => $email,
                    "password" => $password
                ];
                $model = new UserModel();
                $model->insert($data);

                $session = session();
                $session->set("successful_message", "User Registerd Successfully");
                $session->markAsFlashdata("successful_message");
                return view('register');
            } else {
                return redirect()->back()->withInput();
            }
        }
    }

    public function login()
    {
        if ($this->request->getMethod() == "get") {
            echo view('login');
        } elseif ($this->request->getMethod() == "post") {
            if ($this->validate([
                "email" => "required|valid_email",
                "password" => "required",
            ])) {
                $model = new UserModel();
                $record = $model->where("email", $this->request->getVar("email"))
                    ->where("password", $this->request->getVar("password"))
                    ->first();

                $session = session();
                if (!is_null($record)) {
                    $sess_data = [
                        "user_id" => $record['id'],
                        "username" => $record["username"],
                        "email" => $record["email"],
                        "user_type" => $record["user_type"],
                        "loggedin" => "loggedin"
                    ];
                    $session->set($sess_data);
                    if ($record['user_type'] == "user") {
                        $url = "user_dashboard";
                    } elseif ($record["user_type"] == "admin") {
                        $url = "admin/admin_dashboard";
                    }
                    return redirect()->to(base_url($url));
                } else {
                    $session->set("failed_message", "Login Failed, Please Try Again!");
                    $session->markAsFlashdata("failed_message");
                    return redirect()->back()->withInput();
                }
            } else {
                return redirect()->back()->withInput();
            }
        }
    }
    public function logout()
    {
        $session = session();
        session_unset();
        session_destroy();
        return redirect()->to(base_url());
    }

    public function profile()
    {
        if ($this->request->getMethod() == "get") {
            echo view("profile");
        } else if ($this->request->getMethod() == "post") {
            $country = $this->request->getVar("country");
            $state = $this->request->getVar("state");
            $district = $this->request->getVar("district");
            $pincode = $this->request->getVar("pincode");
            $mobile = $this->request->getVar("mobile");
            $local_address = $this->request->getVar("local_address");
            $permanent_address = $this->request->getVar("permanent_address");

            $session = session();
            $model = new UserDetailsModel();
            $user_id = $session->user_id;
            $record = $model->where("user_id", $user_id)->first();
            $data = [
                'user_id' => $user_id,
                'country' => $country,
                'state' => $state,
                'district' => $district,
                'pincode ' => $pincode,
                'mobile' => $mobile,
                'local_address ' => $local_address, 
                'permanent_address' => $permanent_address
            ];
            if(!is_null($record)){ 
                $model->update($user_id, $data);
                }else{
                $model->insert($data);
            }
            return redirect()->to(base_url('profile'));
    }
}
}