<?php

namespace App\Controllers; 
use App\Models\UserModel;
class AdminDashboardController extends BaseController
{
    public function admin_dashboard()
    {
        return view('admin_dashboard/admin_dashboard');
    }
    public function users()
    {
        $model=new UserModel();
        $users= $model->findAll();

        return view('admin_dashboard/users',["users"=>$users]);
    }
}