<?php

namespace App\Controllers; 
use App\Models\UserModel;
class DashboardController extends BaseController
{
    public function user_dashboard(): string
    {
        $model=new UserModel();
        $users= $model->findAll();

        return view('dashboard/user_dashboard',["users"=>$users]);
    }
}