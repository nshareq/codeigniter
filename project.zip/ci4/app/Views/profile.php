<?= $this->extend('public_layout') ?>

<?= $this->section('content') ?>
<div class="container">
    <div class="row">
        <div class="col-sm-12">

            <?php

            use App\Models\UserDetailsModel;

            $model = new UserDetailsModel();
            $session = session();
            $user_id = $session->user_id;
            $record = $model->where("user_id", $user_id)->first()
            ?>

            <div class="col-sm-8 mx-auto my-3">
                <h1>Change everything!</h1>
                <div class="card">
                    <div class="card-body">
                        <form action="<?=base_url("profile")?>" method="post"get">
                            <div class="row">
                                <div class="col">
                                    <label for="country">Country</label>
                                    <input type="text" class="form-control" name="country" id="country" value="<?= !is_null($record) ? $record['country'] : '' ?>">
                                </div>
                                <div class="col">
                                    <label for="state">State</label>
                                    <input type="text" class="form-control" name="state" id="state" value="<?= !is_null($record) ? $record["state"] : "" ?>">
                                </div>
                                <div class="col">
                                    <label for="district">District</label>
                                    <input type="text" class="form-control" name="district" id="district" value="<?= !is_null($record) ? $record["district"] : "" ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <label for="pincode">Pincode</label>
                                    <input type="text" class="form-control" name="pincode" id="pincode" value="<?= !is_null($record) ? $record["pincode"] : "" ?>">
                                </div>
                                <div class="col">
                                    <label for="mobile">Mobile</label>
                                    <input type="text" class="form-control" name="mobile" id="mobile" value="<?= !is_null($record) ? $record["mobile"] : "" ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <label for="local_address">Current Address</label>
                                    <textarea class="form-control" name="local_address" id="local_address"><?= !is_null($record) ? $record["permanent_address"] : "" ?></textarea>
                                </div>
                                <div class="col">
                                    <label for="permament_address">Permament Address</label>
                                    <textarea class="form-control" name="permament_address" id="permament_address"><?= !is_null($record) ? $record["permanent_address"] : "" ?></textarea>
                                </div>
                            </div>
                            <div class="text-center mt-3">
                                <button type="submit" class="btn btn-primary">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>