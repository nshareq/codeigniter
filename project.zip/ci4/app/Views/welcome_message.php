<?= $this->extend('public_layout') ?>

<?= $this->section('content') ?>

<section id="hero">
        <div class="hero-content">
            <h1>Welcome</h1>
            <p>Experience the hell!</p>
            <a href="register" class="cta-button">Get Started</a>
        </div>
    </section>

    <footer>
        <p>&copy; 2023 Your Company Name. All rights reserved.</p>
    </footer>
<?= $this->endSection() ?>