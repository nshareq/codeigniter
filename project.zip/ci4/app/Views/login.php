<?= $this->extend('public_layout') ?>

<?= $this->section('content') ?>

<div class="container">
    <div class="row">
        <div class="col-sm-4 mx-auto">
            <div class="card mt-5">
                <div class="card-body">
                    <h2>Log In.</h2>
                    <?php $session=session(); ?>
                    <?php if(!is_null($session->getFlashdata("failed_message"))): ?>
                    <div class="alert alert-danger">
                        <?= $session->getFlashdata("failed_message") ?>
                    </div>
                    <?php endif ?>

                    <?php $validation = \Config\Services::validation(); ?>
                    <form action="<?= base_url("login") ?>" method="post">
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email address</label>
                            <input type="email" class="form-control" name="email" value="<?= old("email") ?>">
                            <div class="text-danger">
                                <?= $validation->getError("email") ?>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" name="password" value="<?= old("password") ?>">
                            <div class="text-danger">
                                <?= $validation->getError("password") ?>
                            </div>
                        </div>
                        
                        <button type="login" class="btn btn-primary">Login</button>

                    </form>
                    <a href="<?= base_url() ?>register">Don't have an account?</a>
                </div>
            </div>
        </div>
    </div>
</div>




<?= $this->endSection() ?>