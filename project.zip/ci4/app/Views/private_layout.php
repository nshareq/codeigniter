<!doctype html>
<html>
<head>
    <title>My Layout</title>
    <?= $this->include('bootstrap') ?>
    <link href="<?= base_url() ?>/public/css/main.css" rel="stylesheet">
    <link rel="stylesheet" href="<?=base_url()?>public/css/main.css">
</head>
<body>
    <?= $this->include('navbar.php') ?>
    <?= $this->renderSection('content') ?>
</body>
</html>
<script src="<?= base_url() ?>/public/css/main.css"></script>