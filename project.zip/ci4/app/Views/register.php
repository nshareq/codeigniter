<?= $this->extend('public_layout') ?>

<?= $this->section('content') ?>

<div class="container">
    <div class="row">
        <div class="col-sm-4 mx-auto">
            <div class="card mt-5">
                <div class="card-body">
                    <h2>Create New Account</h2>
                    <?php $session=session(); ?>
                    <?php if(!is_null($session->getFlashdata("successful_message"))): ?>
                    <div class="alert alert-success">
                        <?= $session->getFlashdata("successful_message") ?>
                    </div>
                    <?php endif ?>

                    <?php $validation = \Config\Services::validation(); ?>
                    <form action="<?= base_url("register") ?>" method="post">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" name="username" value="<?= old("username") ?>">
                            <div class="text-danger">
                                <?= $validation->getError("username") ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email address</label>
                            <input type="email" class="form-control" name="email" value="<?= old("email") ?>">
                            <div class="text-danger">
                                <?= $validation->getError("email") ?>
                            </div>
                            <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" name="password" value="<?= old("password") ?>">
                            <div class="text-danger">
                                <?= $validation->getError("password") ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="cpassword" class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" name="cpassword" value="<?= old("cpassword") ?>">
                            <div class="text-danger">
                                <?= $validation->getError("cpassword") ?>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Register</button>

                    </form>
                    <a href="<?= base_url() ?>login">Already have an account?</a>
                </div>
            </div>
        </div>
    </div>
</div>




<?= $this->endSection() ?>