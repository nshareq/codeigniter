<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/register', 'Home::register');
$routes->post('/register', 'Home::register');
$routes->get('/login', 'Home::login');
$routes->post('/login', 'Home::login');
$routes->get('/logout', 'Home::logout');
$routes->get('/profile', 'Home::profile');
$routes->post('/profile', 'Home::profile');


$routes->get('/user_dashboard', 'DashboardController::user_dashboard',['filter' => 'login']);

$routes->group('admin', ['filter' => 'admin'], static function($routes){
$routes->get('admin_dashboard', 'AdminDashboardController::admin_dashboard',);
$routes->get('users', 'AdminDashboardController::users');
});



